package main

import "fmt"

// deklarasi variabel global
var pita string
var CC byte
var EOP bool
var index int

// deklarasi prosedure START dan ADV
func START() {
	/* { I.S. pita telah berisi oleh sekumpulan karakter yang diakhiri oleh hashtag '.'
	   F.S. CC berisi karakter pertama dari pita, EOP bernilai true apabila CC
	   adalah '.', false untuk sebaliknya } */
	index = 0
	CC = pita[index]
	EOP = CC == '.'
}

func ADV() {
	/* I.S. EOP bernilai false
	   F.S. CC berisi karakter berikutnya dari CC pada pita karakter saat ini, EOP
	   bernilai true apabila CC adalah '.', false untuk sebaliknya } */
	index += 1
	CC = pita[index]
	EOP = CC == '.'
}
func main() {
	// deklarasi variabel
	// input pita karakter
	fmt.Scan(&pita)
	// nyalakan mesin
	START()
	// proses pita

	var word, status int

	word = 0
	status = 1

	for !EOP {
		if status == 1 {
			if CC == 'F' {
				status = 2
			}
		} else if status == 2 {
			if CC == 'I' {
				status = 3
			} else {
				status = 1
			}
		} else if status == 3 {
			if CC == 'F' {
				word++
				status = 1
			}
		}
		ADV()
	}
	fmt.Println(word)
}
